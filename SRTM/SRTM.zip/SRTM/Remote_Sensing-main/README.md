# Remote_Sensing
Remote Sensing Data - Spring 2023


<h1>Google Classroom code</h1>
dmfvfe
